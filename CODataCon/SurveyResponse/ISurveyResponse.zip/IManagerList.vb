Imports CODataCon.com.controlorigins.ws

Public Interface IManagerList
    WriteOnly Property LookupList As List(Of LookupItem)
    ReadOnly Property Value As String
End Interface

