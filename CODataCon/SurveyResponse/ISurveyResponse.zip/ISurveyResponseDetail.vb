
Public Interface ISurveyResponseDetail
    Sub GetData(ByVal sWhere As String, ByVal OutputCSV As Boolean, ByVal RowCount As Integer, ByVal StartRow As Integer)
End Interface
