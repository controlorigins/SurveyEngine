'Public Interface ISurveyResponseDropdown
'    Function LoadSurveyResponseComboBox(ByRef cbList As System.Web.UI.WebControls.DropDownList) As System.Web.UI.WebControls.DropDownList
'    ReadOnly Property SurveyResponseID As Integer
'    Property ForInput As Boolean
'End Interface
