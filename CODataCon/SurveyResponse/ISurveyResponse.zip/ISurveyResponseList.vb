Imports CODataCon.com.controlorigins.ws

Public Interface ISurveyResponseList
    WriteOnly Property SurveyResponseList As List(Of SurveyResponseItem)
End Interface
